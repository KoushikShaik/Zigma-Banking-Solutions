import { Component, OnInit } from '@angular/core';
import { loginvalidate } from '../loginvalidate';
import { Router } from '@angular/router';
import { cleanSession } from 'selenium-webdriver/safari';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  admin:loginvalidate
  constructor(private router: Router) { 
    this.admin = new loginvalidate()
  }

  ngOnInit() {
  }
  validate(loginform):void{

    if(this.admin.user=="2369190" && this.admin.password=="2369190")
    {
      this.router.navigate(['/homepage'])
      
    
    }
    else{
      
      return alert("Invalid Credentials");
      
      
    }
  }

}

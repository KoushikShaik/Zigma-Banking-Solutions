export class insertcustomer {
    CustomerID: number;
    
    AccountNumber: number;
    NetBankingPassword: string;
    constructor() {
        this.CustomerID = 0
        
        this.AccountNumber = 0
        this.NetBankingPassword = ''
    }
}
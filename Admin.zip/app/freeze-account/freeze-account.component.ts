import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-freeze-account',
  templateUrl: './freeze-account.component.html',
  styleUrls: ['./freeze-account.component.css']
})
export class FreezeAccountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

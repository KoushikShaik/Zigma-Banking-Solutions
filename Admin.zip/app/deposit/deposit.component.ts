import { Component, OnInit } from '@angular/core';
import { depositmoney } from '../deposit';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
cust:depositmoney;
  constructor(private httpClient: HttpClient) { 
    this.cust = new depositmoney();
  }

  ngOnInit() {
  }
  deposit(depositform):void
  {
    this.httpClient.put("http://localhost:59250/api/AccountDetails1/PutBalance",this.cust);
    console.log(this.cust);
  }
}

export class depositmoney {
    AccountNumber :number;
    CurrentBalance: number;
    constructor(){
this.AccountNumber
this.CurrentBalance
    }
}
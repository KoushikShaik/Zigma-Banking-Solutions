export class loginvalidate {
    user:string;
    password:string;
    constructor ()
    {
        this.user=''
        this.password=''
    }
}
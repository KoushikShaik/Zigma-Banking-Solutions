import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import {  insertcustomer } from '../InsertCustomer';
import { Router } from '@angular/router';
import { Alert } from 'selenium-webdriver';
import { format } from 'url';

@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html',
  styleUrls: ['./new-account.component.css']
})
export class NewAccountComponent implements OnInit {
  customer: insertcustomer;
  constructor(private httpClient: HttpClient ,private router: Router ) {
    this.customer = new insertcustomer();
   }

  ngOnInit() {
  }
  insertData(custform): void {
    // console.log(this.customer)
    this.httpClient.post("http://localhost:59250/api/Admin/PostAccountDetail", this.customer).subscribe(res=> console.log(res));

   
    
   alert("Created");
    this.router.navigate(['/newaccount'])

    
    
   
  }

}

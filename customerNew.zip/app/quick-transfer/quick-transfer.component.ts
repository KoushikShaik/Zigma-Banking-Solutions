import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quick-transfer',
  templateUrl: './quick-transfer.component.html',
  styleUrls: ['./quick-transfer.component.css']
})
export class QuickTransferComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

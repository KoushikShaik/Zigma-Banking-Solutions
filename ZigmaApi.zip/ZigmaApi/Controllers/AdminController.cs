﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DataAccessLayer;
using System.Web.Http.Results;
using System.Web.Http.Cors;
namespace ZigmaApi.Controllers
{
    [EnableCors(origins:"http://localhost:4200", headers: "*", methods: "*")]
    public class AdminController : ApiController
    {
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public HttpResponseMessage  getAdminDataToValidate(int userid, string password)
        {
            Admin admin = new Admin();
            bool ans= admin.Admin_Login(userid, password);
            if (ans)
            {
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound,"not valid");
            }
            
                
            
            //if (status)
            //{
            //    Redirect("http://localhost:4200/HomePage.html");
            //}
            //else
            //{
            //     Redirect("http://localhost:4200/index.html");
            //}
        }
    }
}

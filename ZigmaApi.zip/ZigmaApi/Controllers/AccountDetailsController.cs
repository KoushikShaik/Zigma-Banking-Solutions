﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ZigmaApi;
using DataAccessLayer;
using System.Web.Http.Cors;

namespace ZigmaApi.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class AccountDetailsController : ApiController
    {

        private BankingEntities db = new BankingEntities();

        // GET: api/AccountDetails


        // GET: api/AccountDetails/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]


        public IHttpActionResult GetAccountDetail(int id)
        {

            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            return Ok(accountDetail);
        }

        // PUT: api/AccountDetails/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAccountDetail(int id, AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != accountDetail.CustomerID)
            {
                return BadRequest();
            }

            //db.Entry(accountDetail).State = EntityState.Modified;

            AccountDetailsDAL dal = new AccountDetailsDAL();
            dal.RegisterCustomer();

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AccountDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/AccountDetails
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult PostAccountDetail(AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.AccountDetails.Add(accountDetail);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (AccountDetailExists(accountDetail.CustomerID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = accountDetail.CustomerID }, accountDetail);
        }

        // DELETE: api/AccountDetails/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult DeleteAccountDetail(int id)
        {
            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            db.AccountDetails.Remove(accountDetail);
            db.SaveChanges();

            return Ok(accountDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AccountDetailExists(int id)
        {
            return db.AccountDetails.Count(e => e.CustomerID == id) > 0;
        }
    }
}
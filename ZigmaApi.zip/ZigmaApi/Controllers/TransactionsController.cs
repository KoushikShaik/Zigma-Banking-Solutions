﻿using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ZigmaApi;
using System.Web.Http.Cors;

namespace ZigmaApi.Controllers
{
    [EnableCors(origins:"http://localhost:4200",headers:"*",methods:"*")]
    public class TransactionsController : ApiController
    {

        private BankingEntities db = new BankingEntities();
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        // GET: api/Transactions
        public List<Transaction> GetAccountDetails()
        {
            AccountDetailsDAL dal = new AccountDetailsDAL();
            int accno = 2;
            List<BusinessLogicLayer.TransactionBAL> list = dal.ShowTransactionList(accno);
            List<Transaction> statement = new List<ZigmaApi.Transaction>();
            foreach (var item in list)
            {
                Transaction details = new Transaction();
                details.CustomerId_Sender = item.CustomerId_Sender;
                details.AccountNo_Sender = item.AccountNo_Sender;
                details.CustomerId_Recipient = item.CustomerId_Recipient;
                details.AccountNo_Recipient = item.AccountNo_Recipient;
                details.RecipientName = item.RecipientName;
                details.TransactionType = item.TransactionType;
                details.Amount = item.Amount;
                details.TransactionDate = item.Date;
                statement.Add(details);

            }
            return statement;
        }

        // GET: api/Transactions/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(Transaction))]
        public IHttpActionResult GetTransaction(int id)
        {
            Transaction transaction = db.Transactions.Find(id);
            if (transaction == null)
            {
                return NotFound();
            }

            return Ok(transaction);
        }

        // PUT: api/Transactions/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTransaction(int id, Transaction transaction)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != transaction.CustomerId_Sender)
            {
                return BadRequest();
            }

            db.Entry(transaction).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TransactionExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Transactions
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(Transaction))]
        public IHttpActionResult PostTransaction(Transaction transaction)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Transactions.Add(transaction);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (TransactionExists(transaction.CustomerId_Sender))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = transaction.CustomerId_Sender }, transaction);
        }

        // DELETE: api/Transactions/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(Transaction))]
        public IHttpActionResult DeleteTransaction(int id)
        {
            Transaction transaction = db.Transactions.Find(id);
            if (transaction == null)
            {
                return NotFound();
            }

            db.Transactions.Remove(transaction);
            db.SaveChanges();

            return Ok(transaction);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TransactionExists(int id)
        {
            return db.Transactions.Count(e => e.CustomerId_Sender == id) > 0;
        }
    }
}
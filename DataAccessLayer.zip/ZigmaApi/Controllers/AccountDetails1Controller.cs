﻿using BusinessLogicLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;
using ZigmaApi;

namespace ZigmaApi.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class AccountDetails1Controller : ApiController
    {
        private BankingEntities db = new BankingEntities();

        // GET: api/AccountDetails1
        public IQueryable<AccountDetail> GetAccountDetails()
        {
            return db.AccountDetails;
        }

        // GET: api/AccountDetails1/5
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult GetAccountDetail(int id)
        {
            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            return Ok(accountDetail);
        }

        // PUT: api/AccountDetails1/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAccountDetail( AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            AccountDetailsDAL dal = new AccountDetailsDAL();
            AccountDetailsBAL acdetails = new AccountDetailsBAL();
            acdetails.CustomerID = accountDetail.CustomerID;
            acdetails.Name = accountDetail.Name;
            acdetails.Email = accountDetail.Email;
            acdetails.MobileNumber = accountDetail.MobileNumber;
            acdetails.Address = accountDetail.Address;
            acdetails.NetBankingPassword = accountDetail.NetBankingPassword;
            acdetails.TransactionPassword = accountDetail.TransactionPassword;
            bool ans = dal.RegisterCustomer(acdetails);

            //if (id != accountDetail.CustomerID)
            //{
            //    return BadRequest();
            //}

            //db.Entry(accountDetail).State = EntityState.Modified;

            //try
            //{
            //    db.SaveChanges();
            //}
            //catch (DbUpdateConcurrencyException)
            ////{
            ////    //if (!AccountDetailExists(id))
            ////    //{
            ////    //    return NotFound();
            ////    //}
            ////    else
            ////    {
            ////        throw;
            ////    }
            //}

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/AccountDetails1
        [EnableCors(origins: "*", headers: "*", methods: "*")]
       

        public IHttpActionResult PostAccountDetail(string id)
        {
            DataAccessLayer.AccountDetailsDAL dal = new AccountDetailsDAL();
            dal.SendEmail(id);
            return StatusCode(HttpStatusCode.NoContent);

        }


        // DELETE: api/AccountDetails1/5
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult DeleteAccountDetail(int id)
        {
            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            db.AccountDetails.Remove(accountDetail);
            db.SaveChanges();

            return Ok(accountDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AccountDetailExists(int id)
        {
            return db.AccountDetails.Count(e => e.CustomerID == id) > 0;
        }
    }
}
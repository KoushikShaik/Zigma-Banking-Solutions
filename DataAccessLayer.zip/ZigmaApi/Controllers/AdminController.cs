﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ZigmaApi;
using DataAccessLayer;
using BusinessLogicLayer;
using System.Web.Http.Cors;

namespace ZigmaApi.Controllers
{
    [EnableCors(origins: "http://localhost:4201", headers: "*", methods: "*")]
    public class AdminController : ApiController
    {
        private BankingEntities db = new BankingEntities();

        // GET: api/Admin
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IQueryable<AccountDetail> GetAccountDetails()
        {
            return db.AccountDetails;
        }

        // GET: api/Admin/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult GetAccountDetail(int id)
        {
            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            return Ok(accountDetail);
        }

        // PUT: api/Admin/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAccountDetail(int id, AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != accountDetail.CustomerID)
            {
                return BadRequest();
            }

            db.Entry(accountDetail).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AccountDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Admin
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult PostAccountDetail(AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //db.AccountDetails.Add(accountDetail);

            Admin dal = new Admin();
            AccountDetailsBAL acdetails = new AccountDetailsBAL();
            acdetails.AccountNumber = Convert.ToInt64(accountDetail.AccountNumber);
            acdetails.CustomerID = accountDetail.CustomerID;
            acdetails.NetBankingPassword = accountDetail.NetBankingPassword;
            //acdetails.BranchName = accountDetail.BranchName;
            //acdetails.Name = accountDetail.Name;

            //List<AccountDetailsBAL> list = new List<AccountDetailsBAL>();
            //list.Add(acdetails);


            bool ans = dal.InsertCustomerRecord(acdetails);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (AccountDetailExists(accountDetail.CustomerID))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = accountDetail.CustomerID }, accountDetail);
        }

        // DELETE: api/Admin/5
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult DeleteAccountDetail(int id)
        {
            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            db.AccountDetails.Remove(accountDetail);
            db.SaveChanges();

            return Ok(accountDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AccountDetailExists(int id)
        {
            return db.AccountDetails.Count(e => e.CustomerID == id) > 0;
        }
    }
}
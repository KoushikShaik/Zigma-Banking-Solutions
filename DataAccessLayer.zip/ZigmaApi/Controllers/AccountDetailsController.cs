﻿using BusinessLogicLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Description;
using ZigmaApi;

namespace ZigmaApi.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class AccountDetailsController : ApiController
    {
        private BankingEntities db = new BankingEntities();

        // GET: api/AccountDetails
        //public IQueryable<AccountDetail> GetAccountDetails()
        //{
        //    return db.AccountDetails;
        //}

        //// GET: api/AccountDetails/5
        //[ResponseType(typeof(AccountDetail))]
        //public IHttpActionResult GetAccountDetail(int id)
        //{
        //    AccountDetail accountDetail = db.AccountDetails.Find(id);
        //    if (accountDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(accountDetail);
        //}

        // PUT: api/AccountDetails/5

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAccountDetail(int id, AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //if (id != accountDetail.CustomerID)
            //{
            //    return BadRequest();
            //}
            AccountDetailsDAL dal = new AccountDetailsDAL();
            AccountDetailsBAL acdetails = new AccountDetailsBAL();

            acdetails.CustomerID = accountDetail.CustomerID;
            acdetails.Name = accountDetail.Name;
            acdetails.Email = accountDetail.Email;
            acdetails.MobileNumber = accountDetail.MobileNumber;
            acdetails.Address = accountDetail.Address;
            acdetails.NetBankingPassword = accountDetail.NetBankingPassword;
            acdetails.TransactionPassword = accountDetail.TransactionPassword;

            //acdetails.BranchName = accountDetail.BranchName;
            //acdetails.Name = accountDetail.Name;

            //List<AccountDetailsBAL> list = new List<AccountDetailsBAL>();
            //list.Add(acdetails);


            bool ans = dal.RegisterCustomer(acdetails);

            //db.Entry(accountDetail).State = EntityState.Modified;

            //AccountDetailsDAL dal = new AccountDetailsDAL();
            //dal.RegisterCustomer();

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                //if (!AccountDetailExists(id))
                //{
                //    return NotFound();
                //}
                //else
                //{
                //    throw;
                //}
            }

            return StatusCode(HttpStatusCode.NoContent);
        }



        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutAccountUpdate(AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            AccountDetailsDAL dal = new AccountDetailsDAL();
            AccountDetailsBAL acdetails = new AccountDetailsBAL();
            acdetails.CustomerID = accountDetail.CustomerID;
            acdetails.Name = accountDetail.Name;
            acdetails.MobileNumber = accountDetail.MobileNumber;
            acdetails.Address = accountDetail.Address;
            acdetails.NetBankingPassword = accountDetail.NetBankingPassword;
            bool ans = dal.UpdateCustomerRecord(acdetails);
            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                //if (!AccountDetailExists(id))
                //{
                //    return NotFound();
                //}
                //else
                //{
                //    throw;
                //}
            }

            return StatusCode(HttpStatusCode.NoContent);
        }


        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBalance(AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            AccountDetailsDAL dal = new AccountDetailsDAL();
            AccountDetailsBAL acdetails = new AccountDetailsBAL();
            acdetails.AccountNumber = Convert.ToInt64(accountDetail.AccountNumber);
            acdetails.CurrentBalance = Convert.ToInt64(accountDetail.CurrentBalance);

            bool ans = dal.Deposit(acdetails);
            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                //if (!AccountDetailExists(id))
                //{
                //    return NotFound();
                //}
                //else
                //{
                //    throw;
                //}
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/AccountDetails
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult PostAccountDetail(int cid,AccountDetail accountDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // db.AccountDetails.Add(accountDetail);


            Admin dal = new Admin();
            AccountDetailsBAL acdetails = new AccountDetailsBAL();
            acdetails.AccountNumber = Convert.ToInt64(accountDetail.AccountNumber);
            acdetails.CustomerID = accountDetail.CustomerID;
            acdetails.NetBankingPassword = accountDetail.NetBankingPassword;
            //acdetails.BranchName = accountDetail.BranchName;
            acdetails.Name = accountDetail.Name;

            //List<AccountDetailsBAL> list = new List<AccountDetailsBAL>();
            //list.Add(acdetails);


            bool ans = dal.InsertCustomerRecord(acdetails);

            //try
            //{
            //    db.SaveChanges();
            //}
            //catch (DbUpdateException)
            //{
            //    if (AccountDetailExists(accountDetail.CustomerID))
            //    {
            //        return Conflict();
            //    }
            //    else
            //    {
            //        throw;
            //    }
            //}

            return CreatedAtRoute("DefaultApi", new { id = accountDetail.CustomerID }, accountDetail);
        }

        // DELETE: api/AccountDetails/5
        [ResponseType(typeof(AccountDetail))]
        public IHttpActionResult DeleteAccountDetail(int id)
        {
            AccountDetail accountDetail = db.AccountDetails.Find(id);
            if (accountDetail == null)
            {
                return NotFound();
            }

            db.AccountDetails.Remove(accountDetail);
            db.SaveChanges();

            return Ok(accountDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool AccountDetailExists(int id)
        {
            return db.AccountDetails.Count(e => e.CustomerID == id) > 0;
        }
    }
}
﻿using BusinessLogicLayer;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using ZigmaApi;
using System.Web.Http.Cors;

namespace ZigmaApi.Controllers
{
    [EnableCors(origins: "http://localhost:4200", headers: "*", methods: "*")]
    public class BeneficiariesController : ApiController
    {
        private BankingEntities db = new BankingEntities();

        // GET: api/Beneficiaries
        public IQueryable<Beneficiary> GetBeneficiaries()
        {
            return db.Beneficiaries;
        }

        // GET: api/Beneficiaries/5
        [ResponseType(typeof(Beneficiary))]
        public IHttpActionResult GetBeneficiary(string id)
        {
            Beneficiary beneficiary = db.Beneficiaries.Find(id);
            if (beneficiary == null)
            {
                return NotFound();
            }

            return Ok(beneficiary);
        }

        // PUT: api/Beneficiaries/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutBeneficiary(string id, Beneficiary beneficiary)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != beneficiary.BeneficiaryName)
            {
                return BadRequest();
            }

            db.Entry(beneficiary).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!BeneficiaryExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Beneficiaries
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        [ResponseType(typeof(Beneficiary))]
        public IHttpActionResult PostBeneficiary(Beneficiary beneficiary)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            AccountDetailsDAL dal = new AccountDetailsDAL();
            BeneficiaryDetailsBAL acdetails = new BeneficiaryDetailsBAL();
            acdetails.CustomerID = Convert.ToInt32(beneficiary.CustomerID);
            acdetails.BeneficiaryName = beneficiary.BeneficiaryName;
            acdetails.BeneficiaryAccountNo = Convert.ToInt64(beneficiary.BeneficiaryAccountNo);
            acdetails.BeneficiaryIFSC = beneficiary.BeneficiaryIFSC;
            bool ans = dal.AddBeneficiary(acdetails);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (BeneficiaryExists(beneficiary.BeneficiaryName))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = beneficiary.BeneficiaryName }, beneficiary);
        }

        // DELETE: api/Beneficiaries/5
        [ResponseType(typeof(Beneficiary))]
        public IHttpActionResult DeleteBeneficiary(string id)
        {
            Beneficiary beneficiary = db.Beneficiaries.Find(id);
            if (beneficiary == null)
            {
                return NotFound();
            }

            db.Beneficiaries.Remove(beneficiary);
            db.SaveChanges();

            return Ok(beneficiary);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool BeneficiaryExists(string id)
        {
            return db.Beneficiaries.Count(e => e.BeneficiaryName == id) > 0;
        }
    }
}
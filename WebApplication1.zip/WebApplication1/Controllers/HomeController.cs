﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.ServiceReference1;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            int custid = (int)TempData["custid"];
            ServiceReference1.Service1Client cli = new ServiceReference1.Service1Client();
            TransactionBAL[] tranbal = cli.GetDataShowTransactionList(custid);

            List<BusinessLogicLayer.TransactionBAL> tranlist = new List<BusinessLogicLayer.TransactionBAL>();
            foreach (var item in tranbal)
            {
                BusinessLogicLayer.TransactionBAL bal = new BusinessLogicLayer.TransactionBAL();
                bal.AccountNo_Recipient = item.AccountNo_Recipient;
                bal.AccountNo_Sender = item.AccountNo_Sender;
                bal.Amount=item.Amount;
                bal.CustomerId_Recipient=item.CustomerId_Recipient;
                bal.CustomerId_Sender = item.CustomerId_Sender;
                tranlist.Add(bal);
            }
            return View(tranlist);
        }

        public ActionResult ShowTranList()
        {

            return View();
        }

        [HttpPost]
        public ActionResult ShowTranList(int id)
        {
            TempData["custid"] = id;
            return RedirectToAction("Index");
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
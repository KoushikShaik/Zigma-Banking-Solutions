﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class TranBAL
    {

        private int scid;
        public int CustomerId_Sender
        {
            get { return scid; }
            set
            {
                scid = value;
                if (string.IsNullOrEmpty(scid.ToString()))
                {
                    throw new Exception("not a valid scid ");
                }
            }

        }

        //private int rcid;
        //public int CustomerId_Recipient
        //{
        //    get { return rcid; }
        //    set
        //    {
        //        rcid = value;
        //        if (string.IsNullOrEmpty(rcid.ToString()))
        //        {
        //            throw new Exception("not a valid rcid ");
        //        }
        //    }

        //}
        //private long saccno;
        //public long AccountNo_Sender
        //{
        //    get { return saccno; }
        //    set
        //    {
        //        saccno = value;
        //        if (string.IsNullOrEmpty(saccno.ToString()))
        //        {
        //            throw new Exception("not a valid saccno ");
        //        }
        //    }

        //}
        //private long raccno;
        //public long AccountNo_Recipient
        //{
        //    get { return raccno; }
        //    set
        //    {
        //        raccno = value;
        //        if (string.IsNullOrEmpty(raccno.ToString()))
        //        {
        //            throw new Exception("not a valid AccountNo_Recipient ");
        //        }
        //    }

        //}
        //private string rname;
        //public string RecipientName
        //{
        //    get { return rname; }
        //    set
        //    {
        //        rname = value;
        //        if (string.IsNullOrEmpty(rname))
        //        {
        //            throw new Exception("not a valid RecipientName ");
        //        }
        //    }

        //}
        //private long amount;
        //public long Amount
        //{
        //    get { return amount; }
        //    set
        //    {
        //        amount = value;
        //        if (string.IsNullOrEmpty(amount.ToString()))
        //        {
        //            throw new Exception("not a valid status ");
        //        }
        //    }

        //}
        //private string ttype;
        //public string TransactionType
        //{
        //    get { return ttype; }
        //    set
        //    {
        //        ttype = value;
        //        if (string.IsNullOrEmpty(ttype))
        //        {
        //            throw new Exception("not a valid TransactionType ");
        //        }
        //    }

        //}
        //private string ifsc;
        //public string IFSC_code
        //{
        //    get { return ifsc; }
        //    set
        //    {
        //        ifsc = value;
        //        if (string.IsNullOrEmpty(ifsc))
        //        {
        //            throw new Exception("not a valid ifsc ");
        //        }
        //    }

        //}
        //private DateTime date;
        //public DateTime Date
        //{
        //    get { return date; }
        //    set
        //    {
        //        date = value;
        //        if (string.IsNullOrEmpty(date.ToString()))
        //        {
        //            throw new Exception("not a valid ifsc ");
        //        }
        //    }

        //}




    }
}
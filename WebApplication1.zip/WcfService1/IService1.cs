﻿using BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        List<TransactionBAL> GetDataShowTransactionList(int custid);

        [OperationContract]
        CompositeType GetDataUsingDataContract(CompositeType composite);

        // TODO: Add your service operations here
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class CompositeType
    {
        bool boolValue = true;
        string stringValue = "Hello ";

        [DataMember]
        public bool BoolValue
        {
            get { return boolValue; }
            set { boolValue = value; }
        }

        [DataMember]
        public string StringValue
        {
            get { return stringValue; }
            set { stringValue = value; }
        }
    }


    //[DataContract]
    //public class TransactionBALDC
    //{

    //    private int scid;
    //    [DataMember]
    //    public int CustomerId_Sender
    //    {
    //        get { return scid; }
    //        set
    //        {
    //            scid = value;
    //            if (string.IsNullOrEmpty(scid.ToString()))
    //            {
    //                throw new Exception("not a valid scid ");
    //            }
    //        }

    //    }

    //    private int rcid;
    //    [DataMember]
    //    public int CustomerId_Recipient
    //    {
    //        get { return rcid; }
    //        set
    //        {
    //            rcid = value;
    //            if (string.IsNullOrEmpty(rcid.ToString()))
    //            {
    //                throw new Exception("not a valid rcid ");
    //            }
    //        }

    //    }
    //    private long saccno;

    //    [DataMember]
    //    public long AccountNo_Sender
    //    {
    //        get { return saccno; }
    //        set
    //        {
    //            saccno = value;
    //            if (string.IsNullOrEmpty(saccno.ToString()))
    //            {
    //                throw new Exception("not a valid saccno ");
    //            }
    //        }

    //    }
    //    private long raccno;
    //    [DataMember]
    //    public long AccountNo_Recipient
    //    {
    //        get { return raccno; }
    //        set
    //        {
    //            raccno = value;
    //            if (string.IsNullOrEmpty(raccno.ToString()))
    //            {
    //                throw new Exception("not a valid AccountNo_Recipient ");
    //            }
    //        }

    //    }
    //    private string rname;
    //    [DataMember]
    //    public string RecipientName
    //    {
    //        get { return rname; }
    //        set
    //        {
    //            rname = value;
    //            if (string.IsNullOrEmpty(rname))
    //            {
    //                throw new Exception("not a valid RecipientName ");
    //            }
    //        }

    //    }
    //    private long amount;
    //    [DataMember]
    //    public long Amount
    //    {
    //        get { return amount; }
    //        set
    //        {
    //            amount = value;
    //            if (string.IsNullOrEmpty(amount.ToString()))
    //            {
    //                throw new Exception("not a valid status ");
    //            }
    //        }

    //    }
    //    private string ttype;
    //    [DataMember]
    //    public string TransactionType
    //    {
    //        get { return ttype; }
    //        set
    //        {
    //            ttype = value;
    //            if (string.IsNullOrEmpty(ttype))
    //            {
    //                throw new Exception("not a valid TransactionType ");
    //            }
    //        }

    //    }
    //    private string ifsc;
    //    [DataMember]
    //    public string IFSC_code
    //    {
    //        get { return ifsc; }
    //        set
    //        {
    //            ifsc = value;
    //            if (string.IsNullOrEmpty(ifsc))
    //            {
    //                throw new Exception("not a valid ifsc ");
    //            }
    //        }

    //    }
    //    private DateTime date;
    //    [DataMember]
    //    public DateTime Date
    //    {
    //        get { return date; }
    //        set
    //        {
    //            date = value;
    //            if (string.IsNullOrEmpty(date.ToString()))
    //            {
    //                throw new Exception("not a valid ifsc ");
    //            }
    //        }

    //    }
    //}
}

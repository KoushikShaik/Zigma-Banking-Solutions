export class EditCustomer {
    CustomerID: number;
    Name : string;
    MobileNumber : string;
    Address : string;
    NetBankingPassword: string;

    constructor()
    {
        this.CustomerID=0
        this.Name=''
        this.MobileNumber=''
        this.Address=''
        this.NetBankingPassword=''

    }

}
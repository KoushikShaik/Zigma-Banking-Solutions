import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { EditCustomer } from '../editcustomer';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
e:EditCustomer;
  constructor(private httpClient: HttpClient) {
    this.e = new EditCustomer();
   }

  ngOnInit() {
  }
  EditForm(editform): void {
    // console.log(this.customer)
    this.httpClient.put("http://localhost:59250/api/AccountDetails/PutAccountUpdate", this.e).subscribe(res => console.log(res))
 
  }


}

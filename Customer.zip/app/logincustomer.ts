export class validatecustomer{
    CustomerID: string;
    Password : string;
    
    constructor(){
        this.CustomerID
        this.Password
    }
}
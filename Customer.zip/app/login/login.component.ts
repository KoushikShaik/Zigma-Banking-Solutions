import { Component, OnInit } from '@angular/core';
import {validatecustomer } from '../logincustomer';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
cust:validatecustomer
  constructor(private httpClient: HttpClient) {
    this.cust = new validatecustomer();
   }

  ngOnInit() {
  }

}

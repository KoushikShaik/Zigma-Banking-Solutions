export class registerCustomer {
    CustomerID: number;
    Name : string;
    Email : string;
    MobileNumber : string;
    Address : string;
    NetBankingPassword: string;
    TransactionPassword : string;
    constructor() {
        this.CustomerID = 0
        this.Name = ''
        this.Email = ''
        this.MobileNumber=''
        this.Address = ''
        this.NetBankingPassword=''
        this.TransactionPassword=''
      
    }
}
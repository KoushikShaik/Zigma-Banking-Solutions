import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { registerCustomer } from '../registercustomer';
import { RouterLink } from '@angular/router';
@Component({ 
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
rcustomer :registerCustomer;
mailId:string;
  constructor(private httpClient: HttpClient) {
    this.rcustomer = new registerCustomer();
   }

  ngOnInit() {
  }
  id:string;
  registercustomer(custform): void {
    
    // console.log(this.customer)
  this.id=this.rcustomer.Email;
    this.httpClient.put("http://localhost:59250/api/AccountDetails1/PutAccountDetail",this.rcustomer).subscribe(res => console.log(res))
    this.newuserForOTP();
  }

  newuserForOTP()
  {
    sessionStorage.storeEmailid=this.rcustomer.Email;
    this.httpClient.post("http://localhost:59250/api/AccountDetails1/PostAccountDetail",this.id);
    console.log(this.rcustomer.Email)

  }


}

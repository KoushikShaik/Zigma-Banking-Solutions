export class addbeneficiary {
    CustomerID: number;
    BeneficiaryName : string;
    BeneficiaryIFSC : string;
    BeneficiaryAccountNo : number;
    constructor() {
        this.CustomerID 
        this.BeneficiaryName = ''
        this.BeneficiaryIFSC = ''
        this.BeneficiaryAccountNo
 
    }
}
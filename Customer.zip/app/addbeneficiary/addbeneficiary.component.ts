import { Component, OnInit } from '@angular/core';
import { addbeneficiary } from '../add-beneficiary';
import { HttpClient, HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-addbeneficiary',
  templateUrl: './addbeneficiary.component.html',
  styleUrls: ['./addbeneficiary.component.css']
})
export class AddbeneficiaryComponent implements OnInit {
  b:addbeneficiary
  constructor(private httpClient: HttpClient) { 
    this.b = new addbeneficiary();
  }

  ngOnInit() {
  }
  addbeneficiary(beneficiary): void {
    this.httpClient.post("http://localhost:59250/api/Beneficiaries/PostBeneficiary", this.b).subscribe(res => console.log(res))
 
  }

}

vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|20 Nov 2005 10:49:12 -0000
vti_extenderversion:SR|4.0.2.7802

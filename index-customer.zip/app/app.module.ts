import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

import { LoginComponent } from './login/login.component';
import { NewsComponent } from './news/news.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { AddbeneficiaryComponent } from './addbeneficiary/addbeneficiary.component';
import { FundComponent } from './fund/fund.component';
import { Home2Component } from './home2/home2.component';
import { OtpComponent } from './otp/otp.component';
import { QuickTransferComponent } from './quick-transfer/quick-transfer.component';
import { StatementComponent } from './statement/statement.component';
import { TransferComponent } from './transfer/transfer.component';

@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    HeaderComponent,
    FooterComponent,
    
    LoginComponent,
    NewsComponent,
    HomeComponent,
    ProfileComponent,
    EditProfileComponent,
    AddbeneficiaryComponent,
    FundComponent,
    Home2Component,
    OtpComponent,
    QuickTransferComponent,
    StatementComponent,
    TransferComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

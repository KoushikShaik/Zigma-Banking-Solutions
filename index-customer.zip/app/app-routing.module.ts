import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { RegistrationComponent } from './registration/registration.component';
import { HomeComponent } from './home/home.component';
import { AddbeneficiaryComponent } from './addbeneficiary/addbeneficiary.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { FundComponent } from './fund/fund.component';
import { Home2Component } from './home2/home2.component';
import { OtpComponent } from './otp/otp.component';
import { ProfileComponent } from './profile/profile.component';
import { QuickTransferComponent } from './quick-transfer/quick-transfer.component';
import { StatementComponent } from './statement/statement.component';
import { TransferComponent } from './transfer/transfer.component';


const routes: Routes = [
  {
    path :"",
    component : HomeComponent
  },
  {
    path :"registration",
    component : RegistrationComponent
  },
  {
    path :"addbeneficiary",
    component : AddbeneficiaryComponent
  },
  {
    path :"fund",
    component : FundComponent
  },
  {
    path :"edit-profile",
    component : EditProfileComponent
  },
  {
    path :"home2",
    component : Home2Component
  },
  {
    path :"otp",
    component : OtpComponent
  },
  {
    path :"profile",
    component : ProfileComponent
  },
  {
    path :"quick-transfer",
    component : QuickTransferComponent
  },
  {
    path :"statement",
    component : StatementComponent
  },
  {
    path :"transfer",
    component : TransferComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

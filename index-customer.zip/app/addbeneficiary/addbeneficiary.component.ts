import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addbeneficiary',
  templateUrl: './addbeneficiary.component.html',
  styleUrls: ['./addbeneficiary.component.css']
})
export class AddbeneficiaryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regcomplete',
  templateUrl: './regcomplete.component.html',
  styleUrls: ['./regcomplete.component.css']
})
export class RegcompleteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
